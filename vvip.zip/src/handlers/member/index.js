const registerMemberHandlers = (bot, db) => {
    // Member features will be added here
};

module.exports = { registerMemberHandlers };
