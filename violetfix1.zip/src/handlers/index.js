const { registerStart } = require('./start');
const { registerBotCommands } = require('./botCommands');

module.exports = {
    registerStart,
    registerBotCommands
};
